
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Suite.class)
@SuiteClasses({ HangmanTest.class, LetterTest.class })//Perform Integration testing
public class AppTest {


}
